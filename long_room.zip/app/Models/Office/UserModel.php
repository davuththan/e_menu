<?php

namespace App\Models\Office;

use Illuminate\Database\Eloquent\Model;

class UserModel extends Model
{
    //
}
