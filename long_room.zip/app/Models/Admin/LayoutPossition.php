<?php namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class LayoutPossition extends Model {

	protected $table = 'Layout_possition';
	
	protected $fillable = ['name'];

	public $timestamps = false;
	
}
 