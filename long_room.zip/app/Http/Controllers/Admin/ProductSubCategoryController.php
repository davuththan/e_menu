<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ProductSubCategoryRequest;
use Illuminate\Support\Facades\Input;
use App\Models\Admin\ProductSubCategory;
use App\Models\Admin\ProductCategory;
use DB;
use App\user;
use Carbon\Carbon;
use Auth;
use Session;
use Validator;
use rules;
use Redirect;

class ProductSubCategoryController extends Controller
{
	
	public $view_title = "Product Category";
	

    // public function __construct()
    // {

    // }

    
    public function index()
    {
        $product_sub_categories = ProductSubCategory::all();
        return view('Admin.category.product_sub_category.index')
                ->with('product_sub_categories',$product_sub_categories)
                ->with('view_title',$this->view_title);
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $product_category = ProductCategory::lists('name','id');
        return view('Admin.category.product_sub_category.form')
        								->with('view_title',$this->view_title)
                                        ->with('product_category',$product_category)
										->with('action',"Create");
    }

  

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(ProductSubCategoryRequest $request)
    {
        ProductSubCategory::create($request->all());
        return redirect("admin/category/product_sub_category")
                                    ->with('message',"Product Category => (".$request['name'].") has been created.");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $product_sub_category = ProductSubCategory::find($id);
        $product_category = ProductCategory::lists('name','id');
        return view('Admin.category.product_sub_category.form')
                                        ->with('product_sub_category',$product_sub_category)
                                        ->with('product_category',$product_category)
                                        ->with('view_title',$this->view_title)
                                        ->with('action',"View");
    }
 
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product_category = ProductCategory::lists('name','id');
        $product_sub_category = ProductSubCategory::find($id);
        return view('Admin.category.product_sub_category.form')->with('product_sub_category',$product_sub_category)
                                        ->with('product_category',$product_category)
                                        ->with('view_title',$this->view_title)
                                        ->with('action',"Edit");
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ProductSubCategoryRequest $request, $id)
    {
       $ProductSubCategory = ProductSubCategory::find($id);
       $ProductSubCategory->update($request->all());
       return redirect("admin/category/product_sub_category")->with('message',"Product Category => (".$request['name'].") has been modified.");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        ProductSubCategory::find($id)->delete();
        return redirect()->back()->with('message','Deleted Successfully');
    }

}
