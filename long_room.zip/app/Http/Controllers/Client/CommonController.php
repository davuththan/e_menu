<?php

namespace App\Http\Controllers\Client;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Admin\Language;
use App\Models\Admin\Product;
use App\Models\Admin\ProductCategory;
use App\Models\Admin\ProductSubCategory;
use DB;
use App\user;
use Mail;
use Validator;
use Auth;
use App;
use Session;
use Input;

class CommonController extends Controller
{
  public function __construct()
  {
    date_default_timezone_set('Asia/Phnom_Penh');
    $languages = DB::table('language')->get();
    $language_id = Session::get('applangId');
    if($language_id==1){
      App::setLocale('kh');
    }else if($language_id==2){
      App::setLocale('en');
    }else if($language_id==3){
      App::setLocale('ch(simplify)');
    }else if($language_id==4){
      App::setLocale('ch(traditional)');
    }
  }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
      
      if(Session::get('applangId')){
        $language_id = Session::get('applangId');
      }else{
        $language_id = CONFIG_LANGUAGE;
      }

      $products = Product::Limit(6)->get();
      $product_categories = ProductCategory::all();
      $product_sub_categories = ProductSubCategory::Where('pc_id',1)->get();
      return view('Client.home')->with('products',$products)
                                ->with('product_sub_categories',$product_sub_categories)
                                ->with('product_categories',$product_categories);
    }

    public function getPCCategory(Request $request){
      $data = $request->all();

      $pc_id = $data['pc_id'];

      $results = DB::table("product_sub_category")->Where('pc_id',$pc_id)->get();
      $data_arr = array();
      foreach ($results as $result) {
        $data_arr[] = array(
          'psc_id' => $result->id,
          'psc_name_en' => $result->name_en,
          'psc_name_kh' => $result->name_kh,
        );
      }

      $result_products = DB::table("product")->Where('pc_id',$pc_id)->LIMIT(6)->get();

      $data_product_arr = array();
      foreach ($result_products as $result_product) {
        $data_product_arr[] = array(
          'id' => $result_product->id,
          'photo' => $result_product->photo,
          'price' => $result_product->price,
          'name_en' => $result_product->name_en,
          'name_kh' => $result_product->name_kh,
        );
      }

      $data_whole_arr[] = array(
        'sub_cat_product' => $data_arr,
        'product' => $data_product_arr,
      );
      return json_encode($data_whole_arr);
    }

    public function getSPCCategory(Request $request){
      $data = $request->all();

      $spc_id = $data['spc_id'];

      $results = DB::table("product")->Where('spc_id',$spc_id)->Limit(6)->get();
      $data_arr = array();
      foreach ($results as $result) {
        $data_arr[] = array(
          'id' => $result->id,
          'photo' => $result->photo,
          'price' => $result->price,
          'name_en' => $result->name_en,
          'name_kh' => $result->name_kh,
        );
      }

      return json_encode($data_arr);
    }
    
}   
